package jdbc;

public class ProductMain {

	public static void main(String[] args) {
		new ProductController();

	}

}
