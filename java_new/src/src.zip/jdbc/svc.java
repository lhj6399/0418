package jdbc;

public interface svc {

}
